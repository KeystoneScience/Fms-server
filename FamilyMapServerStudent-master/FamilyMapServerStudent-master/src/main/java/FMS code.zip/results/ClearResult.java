package results;

/**
 * Return success vs error messages from clear service
 */
public class ClearResult extends ParentResult{
//Placeholder, as it can be useful to call objects by a certain name.
}
